/**
 * Regenerates the screenshots in results/screenshots/ from the live app.
 *
 * Requires Node.js + Playwright (`npm install playwright` then
 * `npx playwright install chromium` if you don't already have a browser).
 *
 * Usage:
 *   node results/screenshot.js
 */
const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1360, height: 900 } });
  const fileUrl = 'file://' + path.resolve(__dirname, '..', 'index.html');
  const outDir = path.resolve(__dirname, 'screenshots');

  await page.goto(fileUrl);
  await page.waitForTimeout(300);

  await page.screenshot({ path: path.join(outDir, '01-dashboard.png') });

  await page.click('button.tab[data-view="tasks"]');
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(outDir, '02-tasks.png') });

  await page.click('button.tab[data-view="appointments"]');
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(outDir, '03-appointments.png') });

  await page.click('button.tab[data-view="people"]');
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(outDir, '04-people.png') });

  await page.emulateMedia({ colorScheme: 'dark' });
  await page.click('button.tab[data-view="dashboard"]');
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(outDir, '05-dashboard-dark.png') });

  await page.emulateMedia({ colorScheme: 'light' });
  await page.setViewportSize({ width: 420, height: 900 });
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(outDir, '06-mobile-dashboard.png') });

  console.log('Done. Screenshots written to ' + outDir);
  await browser.close();
})();
